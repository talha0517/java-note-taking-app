
# 📝 Java Note Taking App

A simple desktop-based Note Taking application built using Java Swing and Object-Oriented Programming principles.

## 🚀 Features

- Create, edit, and delete notes
- Notes stored locally using Java serialization
- Clean GUI with note title and content sections
- Auto-loads previously saved notes on launch

## 🛠️ Technologies Used

- Java (OOP)
- Java Swing (GUI)
- Object Serialization (Data Persistence)

## 📂 Project Structure

```
NoteTakingApp/
│
├── src/
│   ├── Main.java           # Entry point
│   ├── NoteAppGUI.java     # GUI logic and event handling
│   └── Note.java           # Serializable Note model class
└── notes.ser               # Auto-created file to save user notes
```

## 🎓 Learning Highlights

- Implemented Java Swing for GUI development
- Applied object serialization for file-based storage
- Practiced MVC separation (Note model, GUI, main launcher)
- Improved understanding of event-driven programming

## 💡 How to Run

1. Make sure you have Java installed (JDK 8+).
2. Compile the code:
   ```
   javac src/*.java
   ```
3. Run the application:
   ```
   java -cp src Main
   ```

## 📌 Future Enhancements (Optional Ideas)

- Save notes as text or JSON files
- Add search or filtering functionality
- Tag or categorize notes
- Migrate to mobile (Android) version

---

Feel free to fork, modify, or extend this project. Pull requests are welcome!
