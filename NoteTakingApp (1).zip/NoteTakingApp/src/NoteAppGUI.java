
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;

public class NoteAppGUI extends JFrame {
    private DefaultListModel<Note> noteListModel = new DefaultListModel<>();
    private JList<Note> noteJList = new JList<>(noteListModel);
    private JTextArea noteArea = new JTextArea();
    private JTextField titleField = new JTextField();
    private final String DATA_FILE = "notes.ser";

    public NoteAppGUI() {
        setTitle("Note Taking App");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        noteJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        noteJList.addListSelectionListener(e -> loadSelectedNote());
        JScrollPane listScrollPane = new JScrollPane(noteJList);
        listScrollPane.setPreferredSize(new Dimension(200, 400));
        add(listScrollPane, BorderLayout.WEST);

        JPanel editorPanel = new JPanel(new BorderLayout());
        titleField.setBorder(BorderFactory.createTitledBorder("Title"));
        noteArea.setBorder(BorderFactory.createTitledBorder("Content"));
        editorPanel.add(titleField, BorderLayout.NORTH);
        editorPanel.add(new JScrollPane(noteArea), BorderLayout.CENTER);
        add(editorPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton addBtn = new JButton("Add Note");
        JButton deleteBtn = new JButton("Delete Note");
        JButton saveBtn = new JButton("Save Notes");
        buttonPanel.add(addBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(saveBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> addNote());
        deleteBtn.addActionListener(e -> deleteNote());
        saveBtn.addActionListener(e -> saveNotes());

        loadNotes();
    }

    private void addNote() {
        String title = titleField.getText().trim();
        String content = noteArea.getText().trim();
        if (title.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Title cannot be empty.");
            return;
        }
        Note note = new Note(title, content);
        noteListModel.addElement(note);
        titleField.setText("");
        noteArea.setText("");
    }

    private void loadSelectedNote() {
        Note selected = noteJList.getSelectedValue();
        if (selected != null) {
            titleField.setText(selected.getTitle());
            noteArea.setText(selected.getContent());
        }
    }

    private void deleteNote() {
        int selectedIndex = noteJList.getSelectedIndex();
        if (selectedIndex != -1) {
            noteListModel.remove(selectedIndex);
            titleField.setText("");
            noteArea.setText("");
        }
    }

    private void saveNotes() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            ArrayList<Note> notes = new ArrayList<>();
            for (int i = 0; i < noteListModel.size(); i++) {
                notes.add(noteListModel.getElementAt(i));
            }
            out.writeObject(notes);
            JOptionPane.showMessageDialog(this, "Notes saved successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadNotes() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(DATA_FILE))) {
            ArrayList<Note> notes = (ArrayList<Note>) in.readObject();
            for (Note n : notes) {
                noteListModel.addElement(n);
            }
        } catch (Exception e) {
            // Ignore if file doesn't exist
        }
    }
}
